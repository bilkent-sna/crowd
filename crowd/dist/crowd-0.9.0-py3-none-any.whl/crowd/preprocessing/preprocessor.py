class Preprocessor():
    def process(self, network, args):
        return True