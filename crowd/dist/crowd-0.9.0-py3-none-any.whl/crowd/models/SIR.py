import random
from crowd import node as n

class SIR:

    def update():
        return 0

        