class NodeType:
    def select_action():
        return 