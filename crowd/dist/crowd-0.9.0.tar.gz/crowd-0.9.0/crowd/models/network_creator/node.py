class Node:
    """def __init__(self):
        self.nodetype = nodetype
    def get_nodetype(self):
        return self.nodetype
    """
    def select_actions(self, actions):
        return