class egress:
    def __init__(self, artifact_path):
        self.artifact_path = artifact_path
    

    def save(self):
        pass
    