from setuptools import setup, find_packages

from setuptools.command.install import install

setup(
    name="crowd",
    version="0.9.0",
    packages=find_packages(),
    include_package_data=True,
    # package_data={'': ['*.txt']},
    package_data= {'': ['*.txt'], "network_creator": ['*.yaml'], "visualization":['*.html', '*.geojson']},
    install_requires=[
        "pandas",
        "networkx",
        "pyyaml",
        "python-louvain",
        "imageio",
        "matplotlib",
        "ndlib"
    ],
    # This is to pass Nuitka options.
   command_options={
      'nuitka': {
         # boolean option, e.g. if you cared for C compilation commands
         '--show-scons': True,
         # options without value, e.g. enforce using Clang
         '--clang': None,
         # options with single values, e.g. enable a plugin of Nuitka
         '--enable-plugin': "pyside2",
         # options with several values, e.g. avoid including modules
         '--nofollow-import-to' : ["*.tests", "*.distutils"],
      },
   },
    author="Tolga Yilmaz, Nese Rende",
    description="Crowd:a social network simulation framework",
    keywords="social networks, network, simulation",
    url="https://github.com/Bilkent-Social-Systems-Research-Group/crowd/"
)